# 1.- Project1

# 2.- Jorge De Vivar

# 3-. Fecha de finalizaci�n: 11/3/2022, 
#     Fecha de inicio: 9/3/2022

# 4.- R 4.1.2.

# 5.- Imputaci�n de datos

###############################Cargar librer�as#################################

library (readxl)
library(naniar)
library(visdat)
library(tidyverse)
library(simputation)
library(rio)
library(mice)
library(palmerpenguins)
library(missForest)

################################################################################

############################Introducci�n########################################

# Buscar la ruta del archivo del excel
#file.choose()

# Ruta de la consola y guardar en variable
ruta_excel <- "C:\\Users\\Jorge\\OneDrive\\Escritorio\\TFG\\Codigo\\DatosTFG.xlsx"

# Hojas del Excel
excel_sheets(ruta_excel)

# Importar los datos de la Hoja Exterior
dato_exterior <- read_excel(ruta_excel, sheet = "Exterior")

# Pasar a numerico la Humedad exterior
yna <- suppressWarnings(as.numeric(dato_exterior$Humedad))

# Pasar a numerico la Temperatura exterior
zna <- suppressWarnings(as.numeric(dato_exterior$Temperatura))

#Obtener los datos de tiempo
x <- dato_exterior$FechaNum

# Saber los datos faltantes de la humedad y temperatura exterior
sum(is.na(yna))
sum(is.na(zna))

################################################################################

#######################MISSFOREST###############################################
# Bosques de decisi�n

# Utilizamos el DataFrame
datos <- data.frame (x,yna,zna)

# Hacemos la imputaci�n
imp <- missForest(datos, verbose = TRUE, variablewise = FALSE)
imp$OOBerror
imp <- missForest(datos, verbose = TRUE, variablewise = TRUE)
imp$OOBerror
sapply(datos,class)

datoslimpio <- as.data.frame(imp$ximp)
View(datoslimpio)

################################################################################

################################################################################

# Pasarlos a Excel
setwd("C:\\Users\\Jorge\\OneDrive\\Escritorio\\TFG\\ImputacionMF")
export(datoslimpio,"ImputacionDatos.xlsx")
####FIN CODIGO##################################################################
