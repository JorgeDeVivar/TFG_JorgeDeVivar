# 1.- ImpTemp

# 2.- Jorge De Vivar

# 3-. Fecha de finalizaci�n: 11/3/2022, 
#     Fecha de inicio: 9/3/2022

# 4.- R 4.1.2.

# 5.- Imputaci�n de datos Temperatura

###############################Cargar librer�as#################################

library (readxl)
library(naniar)
library(visdat)
library(tidyverse)
library(simputation)
library(rio)
library(mice)
library(palmerpenguins)
library(missForest)

################################################################################

############################Introducci�n########################################

# Buscar la ruta del archivo del excel
#file.choose()

# Ruta de la consola y guardar en variable
ruta_excel <- "C:\\Users\\Jorge\\OneDrive\\Escritorio\\TFG\\ImputacionTem\\DatosTFG.xlsx"

# Hojas del Excel
excel_sheets(ruta_excel)

# Importar los datos de la Hoja Exterior
dato_exterior <- read_excel(ruta_excel, sheet = "Exterior")

# Pasar a numerico la Temperatura exterior
yna <- suppressWarnings(as.numeric(dato_exterior$Temperatura))

#Obtener los datos de tiempo
x <- dato_exterior$FechaNum

# Saber los datos faltantes de la humedad y temperatura exterior
sum(is.na(yna))

################################################################################


##############Lo necesario para empezar con la imputaci�n#######################

# Saber los datos que utilizo
#muestray <- yna
muestrax <- x
muestray <- yna

# Probabilidad de inclusi�n. 
# Es 2090 por el n�mero de datos que tenemos.
Pi <- rep(1/2090,2090)

# N�mero de datos faltantes
m <- 319

################################################################################

#######Imputaci�n de datos para las siguientes opciones#########################

# Separar los datos
SEPARA.muestras <- function(muestray, muestrax, Pi)
{
  POS.faltantes <- is.na(muestray)
  POS.disponibles <- !POS.faltantes
  datosy.r <- muestray[POS.disponibles]
  datosx.r <- muestrax[POS.disponibles]
  Pi.r <- Pi[POS.disponibles]
  datosx.m <- muestrax[POS.faltantes]
  m <- length(datosx.m)
  list(datosy.r=datosy.r, datosx.r=datosx.r, Pi.r=Pi.r,
       m=m, datosx.m=datosx.m, POS.faltantes=POS.faltantes)
}

################################################################################

###########M�todo de la imputaci�n de la media##################################
METODO.media <- function(datosy.r, Pi.r, m)
{
  Pesos <- 1/Pi.r
  N.est <- sum(Pesos)
  Media <- (1/N.est)*sum(Pesos*datosy.r)
  DONANTES.media <- rep(Media,m)
  DONANTES.media
}

################################################################################

################: M�todo de Cohem###############################################
METODO.cohen <- function(datosy.r, Pi.r, m)
{
  r <- length(Pi.r)
  n <- r + m
  Pesos <- 1/Pi.r
  N.est <- sum(Pesos)
  Media <- (1/N.est)*sum(Pesos*datosy.r)
  Dr <- sqrt((1/N.est)*sum(Pesos*(datosy.r-Media)^2))
  m1 <- round(m/2)
  m2 <- m - m1
  Raiz <- sqrt(n+r+1)/sqrt(r-1)
  DONANTES.cohen <- c(rep(Media+Raiz*Dr,m1),rep(Media-Raiz*Dr,m2))
  DONANTES.cohen
}

################################################################################

##################M�todo de imputaci�n NNI######################################
METODO.NNI <- function(datosy.r, datosx.r, datosx.m, m)
{
  DONANTES.NNI <- c()
  for (j in 1:m)
  {
    Diferencias <- abs(datosx.m[j] - datosx.r)
    Dif.min <- min(Diferencias)
    POS.min <- Dif.min==Diferencias
    DONANTES <- datosy.r[POS.min]
    Num.T <- sum(POS.min)
    if (Num.T==1) DONANTES.NNI <- c(DONANTES.NNI, DONANTES)
    else DONANTES.NNI <- c(DONANTES.NNI, sample(DONANTES,1))
  }
  DONANTES.NNI
}

################################################################################

################M�todos de raz�n y regresi�n####################################
METODO.razon <- function(datosy.r, datosx.r, Pi.r, datosx.m)
{
  Pesos <- 1/Pi.r
  N.est <- sum(Pesos)
  MediaY <- (1/N.est)*sum(Pesos*datosy.r)
  MediaX <- (1/N.est)*sum(Pesos*datosx.r)
  DONANTES.razon <- (MediaY/MediaX)*datosx.m
  DONANTES.razon
}
METODO.regresion <- function(datosy.r, datosx.r, Pi.r, datosx.m)
{
  Pesos <- 1/Pi.r
  N.est <- sum(Pesos)
  MediaY <- (1/N.est)*sum(Pesos*datosy.r)
  MediaX <- (1/N.est)*sum(Pesos*datosx.r)
  Beta.est <- sum(Pesos*(datosx.r-MediaX)*(datosy.r-MediaY))/sum(Pesos*(datosx.r-MediaX)^2)
  DONANTES.reg <- (MediaY/MediaX)*datosx.m
  DONANTES.reg
}
METODO.razon.aleatorio <- function(datosy.r, datosx.r, Pi.r, datosx.m)
{
  Pesos <- 1/Pi.r
  N.est <- sum(Pesos)
  Media <- (1/N.est)*sum(Pesos*datosy.r)
  Desviacion <- sqrt((1/N.est)*sum(Pesos*(datosy.r-Media)^2))
  DONANTES.razonA <- METODO.razon(datosy.r, datosx.r, Pi.r, datosx.m) + rnorm(m,0,Desviacion)
  DONANTES.razonA
}
METODO.regresion.aleatorio <- function(datosy.r, datosx.r, Pi.r, datosx.m)
{
  Pesos <- 1/Pi.r
  N.est <- sum(Pesos)
  Media <- (1/N.est)*sum(Pesos*datosy.r)
  Desviacion <- sqrt((1/N.est)*sum(Pesos*(datosy.r-Media)^2))
  DONANTES.regA <- METODO.regresion(datosy.r, datosx.r, Pi.r, datosx.m) + rnorm(m,0,Desviacion)
  DONANTES.regA
}

################################################################################

######################M�todo de imputaci�n RHD##################################
METODO.RHD <- function(datosy.r, Pi.r, m)
{
  Pesos <- 1/Pi.r
  Prob <- Pesos/sum(Pesos)
  DONANTES.RHD <- sample(datosy.r, m,replace=T, prob=Prob)
  DONANTES.RHD
}

################################################################################


######Hallar las muestras#######################################################

# Devuelve todos los valores de la variable
REALIZA.imputacion <- function(muestray, DONANTES, POS.faltantes)
{
  muestray[POS.faltantes] <- DONANTES
  muestray
}

## Separamos la muestra s n y obtenemos el resto de informaci�on necesaria:
SALIDA <- SEPARA.muestras(muestray, muestrax, Pi)

## Aplicamos el m�todo de imputaci�n media para obtener los donantes:
DONANTES.media <- METODO.media(SALIDA$datosy.r, SALIDA$Pi.r, SALIDA$m)

## Aplicamos el m�todo de cohen para obtener los donantes:
DONANTES.cohen <- METODO.cohen(SALIDA$datosy.r, SALIDA$Pi.r, SALIDA$m)

## Aplicamos el m�todo NNI para obtener los donantes:
DONANTES.NNI <- METODO.NNI(SALIDA$datosy.r, SALIDA$datosx.r, SALIDA$datosx.m, SALIDA$m)

## Aplicamos el m�todo de razon y regresion para obtener los donantes:
DONANTES.razon <- METODO.razon(SALIDA$datosy.r, SALIDA$datosx.r, SALIDA$Pi.r, SALIDA$datosx.m)
DONANTES.reg <- METODO.regresion(SALIDA$datosy.r, SALIDA$datosx.r, SALIDA$Pi.r, SALIDA$datosx.m)
DONANTES.razonA <- METODO.razon.aleatorio(SALIDA$datosy.r, SALIDA$datosx.r, SALIDA$Pi.r, SALIDA$datosx.m)
DONANTES.regA <- METODO.regresion.aleatorio(SALIDA$datosy.r, SALIDA$datosx.r, SALIDA$Pi.r, SALIDA$datosx.m)

## Aplicamos el m�todo de imputaci�n RHD para obtener los donantes:
DONANTES.RHD <- METODO.RHD(SALIDA$datosy.r, SALIDA$Pi.r, SALIDA$m)

## Reemplazamos los datos faltantes por los donantes obtenidos:

IMmedia <- REALIZA.imputacion(muestray, DONANTES.media, SALIDA$POS.faltantes)
IMcohen <- REALIZA.imputacion(muestray, DONANTES.cohen, SALIDA$POS.faltantes)
IMNNI <- REALIZA.imputacion(muestray, DONANTES.NNI, SALIDA$POS.faltantes)
IMrazon <- REALIZA.imputacion(muestray, DONANTES.razon, SALIDA$POS.faltantes)
IMreg <- REALIZA.imputacion(muestray, DONANTES.reg, SALIDA$POS.faltantes)
IMrazonA <- REALIZA.imputacion(muestray, DONANTES.razonA, SALIDA$POS.faltantes)
IMregA <- REALIZA.imputacion(muestray, DONANTES.regA, SALIDA$POS.faltantes)
IMRHD <- REALIZA.imputacion(muestray, DONANTES.RHD, SALIDA$POS.faltantes)

# Data Frame de imputaci�n de datos 
ImputacionDatos <- data.frame(IMmedia, IMcohen, IMNNI, IMrazon, IMreg, IMrazonA, IMregA, IMRHD)

# Pasarlos a Excel
setwd("C:\\Users\\Jorge\\OneDrive\\Escritorio\\TFG\\ImputacionTem")
export(ImputacionDatos,"ImputacionDatos.xlsx")



#################MICE###########################################################
datos <- data.frame (x,yna)

# M�todo simple sin MICE
datos$yna[which(is.na(datos$yna))] = mean(datos$yna,na.rm = TRUE)

# M�todo complejo con cart
my_imp = mice(datos, m = 5, method = c("", "cart","cart"), maxit =20)
finalclean = complete(my_imp,5)


# M�todo complejo con pmm
my_imppmm = mice(datos, m = 5, method = c("", "pmm","pmm"), maxit =20)
finalcleanpmm = complete(my_imp,5)

################################################################################
# Data Frame de imputaci�n de datos 
ImputacionDatos <- data.frame(IMmedia, IMcohen, IMNNI, IMrazon, IMreg, IMrazonA, IMregA, IMRHD, finalclean, finalcleanpmm)

# Pasarlos a Excel
setwd("C:\\Users\\Jorge\\OneDrive\\Escritorio\\TFG\\ImputacionTem")
export(ImputacionDatos,"ImputacionDatos.xlsx")

####FIN CODIGO##################################################################
